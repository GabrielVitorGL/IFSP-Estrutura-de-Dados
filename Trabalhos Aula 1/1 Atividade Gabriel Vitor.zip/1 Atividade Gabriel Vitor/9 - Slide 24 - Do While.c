#include <stdio.h>
#include <stdlib.h>

// GABRIEL VITOR GROSSI LOURENÇO 
// GU3054446
int main()
{
    int i = 395;

    do
    {
        printf("Valor de i: %d \n", i);
        i++;
    } while (i <= 10);

    printf("\n\n");

    system("pause");

    return 0;
}