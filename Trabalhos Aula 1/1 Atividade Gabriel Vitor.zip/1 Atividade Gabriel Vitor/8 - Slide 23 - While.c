#include <stdio.h>
#include <stdlib.h>

// GABRIEL VITOR GROSSI LOURENÇO 
// GU3054446
int main()
{
    int i = 0;

    while (i <= 10)
    {
        printf("Valor de i: %d \n", i);
        i++;
    }

    printf("\n\n");

    system("pause");

    return 0;
}